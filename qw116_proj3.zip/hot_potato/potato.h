typedef struct potato_t
{
    /* data */
    int numsOfhops;
    int trace[512];
    int lengthOfTrace;
}potato;


